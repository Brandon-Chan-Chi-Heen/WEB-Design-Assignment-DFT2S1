--
-- Table structure for table `tblproduct`
--

CREATE TABLE `event` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproduct`S
--

INSERT INTO `event` (`id`,`name`,`image`,`price`) VALUES
(1, '3 Wealth Creation Strategies','Event/eventNo1.jpg', 16.95),
(2, 'Financial Leteracy Workshop', 'Event/eventNo2.jpg', 16.95),
(3, 'Investing Note Trading Cup', 'Event/eventNo3.jpg', 16.95),
(4, 'Employee Investor Program', 'Event/eventNo4.jpg', 24.95);
(5, 'Power Up Your FQ', 'Event/eventNo4.jpg', 35.95);)

